// Original synthesized SFX — deterministic, no downloads, copyright-free.
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const OUT = path.join(process.cwd(), "public", "sfx");
fs.mkdirSync(OUT, {recursive: true});

let seed = 1337;
const rnd = () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const noise = () => rnd() * 2 - 1;

const finish = (name, x, peak = 0.7) => {
  let m = 0;
  for (const v of x) m = Math.max(m, Math.abs(v));
  const g = m > 0 ? peak / m : 1;
  const fade = Math.floor(SR * 0.006);
  for (let i = 0; i < x.length; i++) {
    x[i] *= g;
    const k = x.length - 1 - i;
    if (k < fade) x[i] *= k / fade;
  }
  const n = x.length;
  const b = Buffer.alloc(44 + n * 2);
  b.write("RIFF", 0); b.writeUInt32LE(36 + n * 2, 4); b.write("WAVE", 8);
  b.write("fmt ", 12); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20);
  b.writeUInt16LE(1, 22); b.writeUInt32LE(SR, 24); b.writeUInt32LE(SR * 2, 28);
  b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34); b.write("data", 36);
  b.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) b.writeInt16LE(Math.round(Math.max(-1, Math.min(1, x[i])) * 32767), 44 + i * 2);
  fs.writeFileSync(path.join(OUT, name + ".wav"), b);
  console.log(name.padEnd(8), (n / SR).toFixed(2) + "s");
};

const buf = (d) => new Float32Array(Math.floor(SR * d));

// pop: short pitch-dropping sine
const pop = (name, f0, f1) => {
  const x = buf(0.2); let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = f1 + (f0 - f1) * Math.exp(-t * 28);
    ph += (2 * Math.PI * f) / SR;
    const env = (1 - Math.exp(-t * 900)) * Math.exp(-t * 22);
    x[i] = (Math.sin(ph) + 0.15 * Math.sin(2 * ph)) * env;
  }
  finish(name, x);
};
pop("pop", 640, 240);
pop("pop2", 720, 270);

// click: filtered noise tick + tiny sine
{
  const x = buf(0.08); let prev = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR; const n = noise(); const hp = n - prev; prev = n;
    x[i] = hp * Math.exp(-t * 170) * 0.7 + Math.sin(2 * Math.PI * 2200 * t) * Math.exp(-t * 110) * 0.5;
  }
  finish("click", x);
}

// whoosh: band-pass noise sweep (state-variable filter)
{
  const d = 0.72; const x = buf(d);
  let low = 0, band = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR; const u = t / d;
    const fc = 250 * Math.pow(14, u);
    const f = 2 * Math.sin(Math.PI * fc / SR); const q = 0.62;
    const n = noise();
    low += f * band; const high = n - low - q * band; band += f * high;
    const env = Math.pow(Math.sin(Math.PI * Math.pow(u, 0.7)), 2);
    x[i] = band * env;
  }
  finish("whoosh", x, 0.6);
}

// chime: soft pluck + overtones, short decay
{
  const x = buf(0.55);
  const parts = [[880, 1], [1320, 0.35], [1760, 0.22]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR; let s = 0;
    parts.forEach(([f, a], k) => { s += a * Math.sin(2 * Math.PI * f * t) * Math.exp(-t * (7 + k * 4)); });
    x[i] = s * (1 - Math.exp(-t * 1200));
  }
  finish("chime", x, 0.6);
}

// impact: very soft low thump
{
  const x = buf(0.32); let ph = 0; let lp = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 48 + 32 * Math.exp(-t * 14);
    ph += (2 * Math.PI * f) / SR;
    lp += 0.08 * (noise() - lp);
    x[i] = Math.sin(ph) * Math.exp(-t * 11) + lp * Math.exp(-t * 60) * 1.2;
  }
  finish("impact", x, 0.7);
}
