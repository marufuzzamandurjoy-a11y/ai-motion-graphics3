import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile} from "remotion";
import {AUDIO} from "./config";
import {SCENES, TOTAL, WORDS, fr, local} from "./cues";
import {BgMesh, Grade, Grain, Vignette, WipeStreak} from "./components/Layers";
import {SceneA} from "./scenes/SceneA";
import {SceneB} from "./scenes/SceneB";
import {SceneC} from "./scenes/SceneC";

type Sfx = {name: "pop" | "pop2" | "click" | "whoosh" | "chime" | "impact"; at: number; vol: number};

// Global-frame SFX map (few, meaningful events only; SFX volume 0.2–0.3).
const sfx: Sfx[] = [
  {name: "whoosh", at: 0, vol: 0.22},
  {name: "impact", at: SCENES.a.from + local(SCENES.a, WORDS.a.slam), vol: 0.3},
  {name: "pop", at: SCENES.a.from + local(SCENES.a, WORDS.a.slam), vol: 0.26},
  {name: "whoosh", at: SCENES.b.from - 3, vol: 0.22},
  {name: "pop", at: SCENES.b.from + local(SCENES.b, WORDS.b.kono), vol: 0.26},
  {name: "click", at: SCENES.b.from + local(SCENES.b, WORDS.b.strike), vol: 0.3},
  {name: "chime", at: SCENES.b.from + local(SCENES.b, WORDS.b.chhara), vol: 0.26},
  {name: "whoosh", at: SCENES.c.from - 3, vol: 0.22},
  {name: "chime", at: SCENES.c.from + local(SCENES.c, WORDS.c.ai), vol: 0.26},
  {name: "pop2", at: SCENES.c.from + local(SCENES.c, WORDS.c.motion), vol: 0.24},
  {name: "pop", at: SCENES.c.from + local(SCENES.c, WORDS.c.video), vol: 0.24},
  {name: "click", at: SCENES.c.from + local(SCENES.c, WORDS.c.banano), vol: 0.28},
  {name: "impact", at: SCENES.c.from + local(SCENES.c, WORDS.c.banano) + fr(1300), vol: 0.24},
];

export const Main: React.FC = () => {
  return (
    <AbsoluteFill>
      {/* 1 — background */}
      <BgMesh />

      {/* 2/3 — scenes (graphics + type) */}
      <Sequence from={SCENES.a.from} durationInFrames={SCENES.a.to - SCENES.a.from}>
        <SceneA />
      </Sequence>
      <Sequence from={SCENES.b.from} durationInFrames={SCENES.b.to - SCENES.b.from}>
        <SceneB />
      </Sequence>
      <Sequence from={SCENES.c.from} durationInFrames={SCENES.c.to - SCENES.c.from}>
        <SceneC />
      </Sequence>

      {/* transition streaks at the two cuts */}
      <WipeStreak start={SCENES.b.from} />
      <WipeStreak start={SCENES.c.from} />

      {/* 4 — color grade, 5 — grain + vignette */}
      <Grade />
      <Grain />
      <Vignette />

      {/* audio */}
      {AUDIO.voiceover && <Audio src={staticFile("voiceover.mp3")} volume={1} />}
      {AUDIO.sfx &&
        sfx.map((s, i) => (
          <Sequence key={i} from={Math.max(0, s.at)} durationInFrames={fr(900)}>
            <Audio src={staticFile(`sfx/${s.name}.wav`)} volume={s.vol} />
          </Sequence>
        ))}
    </AbsoluteFill>
  );
};
