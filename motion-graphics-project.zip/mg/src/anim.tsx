import React from "react";
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import {theme} from "./theme";

export const clamp = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;

export type SpringCfg = {damping: number; stiffness: number; mass: number};

export const useEnter = (delay = 0, config: SpringCfg = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - delay, fps, config});
};

// opacity + translateY + scale together, never a lone fade.
export const Entrance: React.FC<{
  delay?: number;
  y?: number;
  from?: number;
  config?: SpringCfg;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({delay = 0, y = 40, from = 0.94, config, style, children}) => {
  const p = useEnter(delay, config ?? theme.spring.smooth);
  return (
    <div
      style={{
        opacity: p,
        transform: `translateY(${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

// Whole-word mask reveal (Bengali-safe: never splits inside a word).
export const MaskText: React.FC<{
  delay?: number;
  children: React.ReactNode;
  config?: SpringCfg;
}> = ({delay = 0, children, config}) => {
  const p = useEnter(delay, config ?? theme.spring.snappy);
  return (
    <span
      style={{
        display: "inline-block",
        overflow: "hidden",
        paddingTop: "0.12em",
        paddingBottom: "0.22em",
        verticalAlign: "top",
      }}
    >
      <span
        style={{
          display: "inline-block",
          opacity: interpolate(p, [0, 0.4], [0, 1], clamp),
          transform: `translateY(${interpolate(p, [0, 1], [118, 0])}%)`,
        }}
      >
        {children}
      </span>
    </span>
  );
};

// Word-by-word stagger. Splits ONLY on whitespace.
export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  gap?: number;
  style?: React.CSSProperties;
}> = ({text, delay = 0, per = 4, gap = 24, style}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div style={{display: "flex", flexWrap: "nowrap", gap, ...style}}>
      {text.split(/\s+/).map((word, i) => {
        const p = spring({
          frame: frame - delay - i * per,
          fps,
          config: theme.spring.snappy,
        });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: p,
              transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
            }}
          >
            {word}
          </span>
        );
      })}
    </div>
  );
};

// Gradient keyword with an animated highlight sweep.
export const GradientText: React.FC<{
  sweepFrom?: number;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({sweepFrom = 0, style, children}) => {
  const frame = useCurrentFrame();
  const pos = interpolate(frame, [sweepFrom, sweepFrom + 36], [100, 0], {
    easing: theme.ease.out,
    ...clamp,
  });
  return (
    <span
      style={{
        display: "inline-block",
        padding: "0 0.04em",
        backgroundImage: `linear-gradient(100deg, ${theme.colors.primary} 20%, ${theme.colors.accent} 50%, ${theme.colors.primary} 80%)`,
        backgroundSize: "260% 100%",
        backgroundPosition: `${pos}% 0`,
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
        WebkitTextFillColor: "transparent",
        color: "transparent",
        ...style,
      }}
    >
      {children}
    </span>
  );
};

// Faster-than-entrance exit applied to a whole scene.
export const SceneShell: React.FC<{exit?: boolean; children: React.ReactNode}> = ({
  exit = true,
  children,
}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const t = exit
    ? interpolate(frame, [durationInFrames - theme.dur.exit, durationInFrames], [0, 1], {
        easing: theme.ease.in,
        ...clamp,
      })
    : 0;
  return (
    <AbsoluteFill
      style={{
        fontFamily: theme.fonts.main,
        color: theme.colors.text,
        opacity: 1 - t,
        transform: `translateY(${-40 * t}px) scale(${1 + 0.04 * t})`,
        filter: t > 0 ? `blur(${t * 10}px)` : undefined,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
