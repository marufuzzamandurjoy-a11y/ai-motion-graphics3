import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {clamp} from "../anim";

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 50;
  const d2 = Math.cos(frame / 70) * 40;
  return (
    <AbsoluteFill style={{background: theme.colors.bg}}>
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -520,
          left: -340 + d1,
          filter: "blur(50px)",
          background: `radial-gradient(circle, ${theme.colors.primary}44, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -460,
          right: -260 - d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.accent}26, transparent 65%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${theme.colors.stroke} 1.5px, transparent 1.5px)`,
          backgroundSize: "64px 64px",
          opacity: 0.35,
        }}
      />
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill
      style={{
        backgroundColor: theme.colors.primary,
        mixBlendMode: "soft-light",
        opacity: 0.2,
      }}
    />
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.22))",
      }}
    />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background:
        "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.3) 100%)",
    }}
  />
);

// Hand-rolled mask wipe used at scene cuts. `start` is a global frame.
export const WipeStreak: React.FC<{start: number; length?: number}> = ({
  start,
  length = 16,
}) => {
  const frame = useCurrentFrame();
  const t = interpolate(frame, [start, start + length], [0, 1], {
    easing: theme.ease.inOut,
    ...clamp,
  });
  if (frame < start || frame > start + length) return null;
  return (
    <AbsoluteFill style={{pointerEvents: "none", overflow: "hidden"}}>
      <div
        style={{
          position: "absolute",
          top: -100,
          height: 1300,
          width: 280,
          left: interpolate(t, [0, 1], [-500, 2200]),
          transform: "skewX(-14deg)",
          filter: "blur(6px)",
          background: `linear-gradient(90deg, transparent, ${theme.colors.primary}CC, ${theme.colors.accent}99, transparent)`,
          opacity: 0.85,
        }}
      />
    </AbsoluteFill>
  );
};
