// Preview / render switches.
// voiceover: public/voiceover.mp3 বাজবে কি না (Studio preview ও render দুই ক্ষেত্রেই প্রযোজ্য)
// sfx: public/sfx/*.wav বাজবে কি না
export const AUDIO = {
  voiceover: true,
  sfx: true,
};
