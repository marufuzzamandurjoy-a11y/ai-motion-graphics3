// All timing derives from public/voiceover.srt (ms) and FPS.
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

export const fr = (ms: number) => Math.round((ms / 1000) * FPS);

// Visuals land a few frames before the spoken word.
export const LEAD = 5;
// Scenes overlap slightly so exit + entrance cross over.
const PAD = 6;

export const CUES = [
  {start: 0, end: 3200, text: "আজিজ কাক্কো, এখন"},
  {start: 3200, end: 6800, text: "কোনো স্কিল ছাড়াই"},
  {start: 6800, end: 12000, text: "AI দিয়ে মোশন গ্রাফিক্স ভিডিও বানানো যায়।"},
] as const;

export const TOTAL = fr(CUES[2].end);

export type Scene = {from: number; to: number};
export const SCENES: {a: Scene; b: Scene; c: Scene} = {
  a: {from: 0, to: fr(CUES[0].end) + PAD},
  b: {from: fr(CUES[1].start) - PAD, to: fr(CUES[1].end) + PAD},
  c: {from: fr(CUES[2].start) - PAD, to: TOTAL},
};

// Scene-local frame of a spoken moment (ms on the global SRT clock).
export const local = (scene: Scene, ms: number) =>
  Math.max(0, fr(ms) - scene.from - LEAD);

// Word moments inside each cue (estimated inside the cue; the SRT has no
// word-level timestamps). Adjust here if the voiceover needs tighter sync.
export const WORDS = {
  a: {slam: 2100},
  b: {kono: 3200, skill: 3900, strike: 4500, chhara: 5000},
  c: {ai: 6800, motion: 7900, video: 9200, banano: 10000},
} as const;
