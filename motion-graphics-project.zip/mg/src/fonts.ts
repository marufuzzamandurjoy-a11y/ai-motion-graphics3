import {loadFont} from "@remotion/google-fonts/HindSiliguri";

// Ligature-friendly Bengali font (Latin glyphs included for "AI").
export const {fontFamily} = loadFont("normal", {
  weights: ["500", "700"],
  subsets: ["bengali", "latin"],
});
