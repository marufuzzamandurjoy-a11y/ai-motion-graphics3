import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {SCENES, WORDS, local} from "../cues";
import {GradientText, MaskText, SceneShell, WordReveal, clamp} from "../anim";

// Cue 1 — hook: the name lands big, then yields to the hero word "এখন".
export const SceneA: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const slam = local(SCENES.a, WORDS.a.slam);

  const shrink = interpolate(frame, [slam - 8, slam + 8], [0, 1], {
    easing: theme.ease.inOut,
    ...clamp,
  });
  const nameY = interpolate(shrink, [0, 1], [0, -250]);
  const nameScale = interpolate(shrink, [0, 1], [1, 0.5]);
  const nameOpacity = interpolate(shrink, [0, 1], [1, 0.6]);

  const wave = interpolate(frame, [slam, slam + 22], [0, 1], {
    easing: theme.ease.out,
    ...clamp,
  });
  const underline = interpolate(frame, [slam + 10, slam + 30], [0, 1], {
    easing: theme.ease.out,
    ...clamp,
  });
  const nowBreathe = 1 + Math.sin(frame / 20) * 0.012;

  return (
    <SceneShell>
      {/* concentric rings */}
      <AbsoluteFill>
        {[0, 1, 2].map((i) => {
          const p = spring({frame: frame - i * 7, fps, config: theme.spring.smooth});
          const r = 260 + i * 170;
          const breathe = 1 + Math.sin((frame + i * 14) / 26) * 0.012;
          return (
            <div
              key={i}
              style={{
                position: "absolute",
                left: "50%",
                top: "50%",
                width: r * 2,
                height: r * 2,
                marginLeft: -r,
                marginTop: -r,
                borderRadius: "50%",
                border: `2px solid ${theme.colors.primary}`,
                opacity: p * (0.34 - i * 0.09),
                transform: `scale(${interpolate(p, [0, 1], [0.6, 1]) * breathe})`,
              }}
            />
          );
        })}
        {/* shockwave on the slam */}
        {frame >= slam && (
          <div
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              width: 500 + wave * 1700,
              height: 500 + wave * 1700,
              marginLeft: -(250 + wave * 850),
              marginTop: -(250 + wave * 850),
              borderRadius: "50%",
              border: `4px solid ${theme.colors.accent}`,
              opacity: (1 - wave) * 0.8,
            }}
          />
        )}
      </AbsoluteFill>

      {/* name — big, then recedes */}
      <AbsoluteFill style={{alignItems: "center", justifyContent: "center"}}>
        <div
          style={{
            opacity: nameOpacity,
            transform: `translateY(${nameY}px) scale(${nameScale})`,
            fontSize: 170,
            fontWeight: theme.weights.bold,
            lineHeight: 1.4,
            letterSpacing: 0,
          }}
        >
          <WordReveal text="আজিজ কাক্কো," delay={2} per={5} gap={40} />
        </div>
      </AbsoluteFill>

      {/* hero word */}
      <AbsoluteFill style={{alignItems: "center", justifyContent: "center"}}>
        <div style={{transform: `translateY(70px) scale(${nowBreathe})`, position: "relative"}}>
          <div
            style={{
              fontSize: 340,
              fontWeight: theme.weights.bold,
              lineHeight: 1.4,
              letterSpacing: 0,
            }}
          >
            {frame >= slam - 2 && (
              <MaskText delay={slam} config={theme.spring.bouncy}>
                <GradientText sweepFrom={slam}>এখন</GradientText>
              </MaskText>
            )}
          </div>
          <svg
            width={680}
            height={40}
            viewBox="0 0 680 40"
            style={{position: "absolute", left: "50%", marginLeft: -340, bottom: -10}}
          >
            <path
              d="M10 24 C 160 6, 380 40, 670 14"
              fill="none"
              stroke={theme.colors.accent}
              strokeWidth={8}
              strokeLinecap="round"
              pathLength={1}
              strokeDasharray={1}
              strokeDashoffset={1 - underline}
            />
          </svg>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
