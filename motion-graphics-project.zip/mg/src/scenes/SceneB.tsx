import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {SCENES, WORDS, local} from "../cues";
import {Entrance, GradientText, MaskText, SceneShell, clamp, useEnter} from "../anim";

const SEGMENTS = 10;

// Cue 2 — "কোনো স্কিল ছাড়াই": an empty skill meter, "স্কিল" struck out, then a check.
export const SceneB: React.FC = () => {
  const frame = useCurrentFrame();
  const kono = local(SCENES.b, WORDS.b.kono);
  const skill = local(SCENES.b, WORDS.b.skill);
  const strike = local(SCENES.b, WORDS.b.strike);
  const chhara = local(SCENES.b, WORDS.b.chhara);

  const strikeP = interpolate(frame, [strike, strike + 12], [0, 1], {
    easing: theme.ease.out,
    ...clamp,
  });
  const checkP = useEnter(chhara, theme.spring.bouncy);
  const checkDraw = interpolate(frame, [chhara + 2, chhara + 16], [0, 1], {
    easing: theme.ease.out,
    ...clamp,
  });
  const scan = Math.floor(frame / 5) % (SEGMENTS + 6);
  const float = Math.sin(frame / 30) * 3;

  return (
    <SceneShell>
      <AbsoluteFill
        style={{alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 28}}
      >
        {/* skill meter card — stays empty */}
        <div style={{transform: `translateY(${float}px)`}}>
          <Entrance delay={kono} y={50}>
            <div
              style={{
                width: 980,
                height: 150,
                borderRadius: theme.radius.md,
                background: theme.colors.glass,
                border: `1.5px solid ${theme.colors.stroke}`,
                boxShadow: theme.shadow.card,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "0 44px",
              }}
            >
              <div
                style={{
                  fontSize: 46,
                  fontWeight: theme.weights.bold,
                  color: theme.colors.textDim,
                  lineHeight: 1.4,
                  width: 150,
                }}
              >
                স্কিল
              </div>
              <div style={{display: "flex", gap: 14}}>
                {Array.from({length: SEGMENTS}).map((_, i) => {
                  const p = useEnter(skill + i * 3, theme.spring.snappy);
                  const lit = Math.max(0, 1 - Math.abs(scan - i) / 2.5) * 0.14;
                  return (
                    <div
                      key={i}
                      style={{
                        width: 56,
                        height: 62,
                        borderRadius: 12,
                        border: `2px solid ${theme.colors.stroke}`,
                        background: `rgba(245,240,255,${lit})`,
                        opacity: p,
                        transform: `scaleY(${interpolate(p, [0, 1], [0.5, 1])})`,
                      }}
                    />
                  );
                })}
              </div>
              <svg width={84} height={84} viewBox="0 0 84 84" style={{width: 84}}>
                <circle
                  cx={42}
                  cy={42}
                  r={36}
                  fill="none"
                  stroke={theme.colors.stroke}
                  strokeWidth={4}
                />
                <g
                  style={{
                    transformOrigin: "42px 42px",
                    transform: `scale(${interpolate(checkP, [0, 1], [0.6, 1])})`,
                    opacity: checkP,
                  }}
                >
                  <circle cx={42} cy={42} r={36} fill={theme.colors.primary} />
                  <path
                    d="M25 43 L37 55 L60 30"
                    fill="none"
                    stroke={theme.colors.text}
                    strokeWidth={7}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    pathLength={1}
                    strokeDasharray={1}
                    strokeDashoffset={1 - checkDraw}
                  />
                </g>
              </svg>
            </div>
          </Entrance>
        </div>

        {/* headline */}
        <div style={{display: "flex", alignItems: "center", gap: 40, lineHeight: 1.4}}>
          <div
            style={{
              fontSize: 120,
              fontWeight: theme.weights.bold,
              color: theme.colors.textDim,
              letterSpacing: 0,
            }}
          >
            <MaskText delay={kono + 2}>কোনো</MaskText>
          </div>
          <div
            style={{
              position: "relative",
              fontSize: 160,
              fontWeight: theme.weights.bold,
              letterSpacing: 0,
            }}
          >
            <MaskText delay={skill}>স্কিল</MaskText>
            <div
              style={{
                position: "absolute",
                left: -14,
                top: "56%",
                height: 11,
                width: "calc(100% + 28px)",
                borderRadius: 6,
                background: theme.colors.accent,
                transformOrigin: "left center",
                transform: `scaleX(${strikeP})`,
              }}
            />
          </div>
        </div>
        <div
          style={{
            fontSize: 270,
            fontWeight: theme.weights.bold,
            lineHeight: 1.4,
            letterSpacing: 0,
          }}
        >
          <MaskText delay={chhara} config={theme.spring.bouncy}>
            <GradientText sweepFrom={chhara}>ছাড়াই</GradientText>
          </MaskText>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
