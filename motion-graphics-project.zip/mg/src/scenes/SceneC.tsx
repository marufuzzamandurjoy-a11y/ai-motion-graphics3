import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {SCENES, TOTAL, WORDS, fr, local} from "../cues";
import {Entrance, GradientText, MaskText, SceneShell, clamp, useEnter} from "../anim";

const CARD_W = 800;
const INNER = 752;

const CLIPS = [
  {l: 0.04, w: 0.46, color: theme.colors.primary},
  {l: 0.3, w: 0.4, color: theme.colors.accent},
  {l: 0.12, w: 0.62, color: theme.colors.textDim},
];
const KEYS = [
  {track: 0, x: 0.2},
  {track: 0, x: 0.42},
  {track: 1, x: 0.5},
  {track: 2, x: 0.62},
];

const Editor: React.FC<{
  enter: number;
  clipsAt: number;
  playStart: number;
  playEnd: number;
}> = ({enter, clipsAt, playStart, playEnd}) => {
  const frame = useCurrentFrame();
  const pr = interpolate(frame, [playStart, playEnd], [0, 1], {
    easing: theme.ease.inOut,
    ...clamp,
  });
  const float = Math.sin(frame / 32) * 4;
  const head = useEnter(clipsAt + 10, theme.spring.snappy);
  const s0 = useEnter(clipsAt, theme.spring.bouncy);
  const s1 = useEnter(clipsAt + 5, theme.spring.bouncy);
  const s2 = useEnter(clipsAt + 10, theme.spring.bouncy);
  const idle = 1 + Math.sin(frame / 18) * 0.04;

  return (
    <div style={{transform: `translateY(${float}px)`}}>
      <Entrance delay={enter} y={60} from={0.92}>
        <div
          style={{
            position: "relative",
            width: CARD_W,
            height: 520,
            borderRadius: theme.radius.md,
            background: theme.colors.glass,
            border: `1.5px solid ${theme.colors.stroke}`,
            boxShadow: theme.shadow.card,
            overflow: "hidden",
          }}
        >
          {/* window dots */}
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                top: 24,
                left: 28 + i * 26,
                width: 14,
                height: 14,
                borderRadius: 7,
                background: theme.colors.stroke,
              }}
            />
          ))}
          {/* preview */}
          <div
            style={{
              position: "absolute",
              top: 58,
              left: 24,
              width: INNER,
              height: 270,
              borderRadius: theme.radius.sm,
              background: `linear-gradient(160deg, ${theme.colors.bgAlt}, ${theme.colors.bg})`,
              border: `1px solid ${theme.colors.stroke}`,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                position: "absolute",
                left: 60 + pr * 540,
                top: 90 + Math.sin(pr * Math.PI * 2) * 50,
                width: 84,
                height: 84,
                borderRadius: "50%",
                background: theme.colors.primary,
                opacity: s0,
                transform: `scale(${interpolate(s0, [0, 1], [0.3, 1]) * idle})`,
                boxShadow: theme.shadow.heroGlow,
              }}
            />
            <div
              style={{
                position: "absolute",
                left: 620 - pr * 330,
                top: 140 - Math.sin(pr * Math.PI) * 60,
                width: 68,
                height: 68,
                borderRadius: 14,
                border: `5px solid ${theme.colors.accent}`,
                opacity: s1,
                transform: `rotate(${pr * 360}deg) scale(${interpolate(s1, [0, 1], [0.3, 1])})`,
              }}
            />
            <svg
              width={70}
              height={70}
              viewBox="0 0 70 70"
              style={{
                position: "absolute",
                left: 300 + Math.sin(pr * Math.PI * 2) * 80,
                top: 40 + pr * 130,
                opacity: s2,
                transform: `scale(${interpolate(s2, [0, 1], [0.3, 1]) * idle})`,
              }}
            >
              <polygon points="35,6 64,60 6,60" fill="none" stroke={theme.colors.text} strokeWidth={5} strokeLinejoin="round" />
            </svg>
          </div>
          {/* timeline */}
          <div style={{position: "absolute", top: 352, left: 24, width: INNER, height: 150}}>
            {CLIPS.map((c, i) => {
              const p = useEnter(clipsAt + i * 5, theme.spring.smooth);
              return (
                <div
                  key={i}
                  style={{
                    position: "absolute",
                    top: i * 50,
                    left: c.l * INNER,
                    width: c.w * INNER,
                    height: 38,
                    borderRadius: 10,
                    background: c.color,
                    opacity: p * (i === 2 ? 0.45 : 0.9),
                    transformOrigin: "left center",
                    transform: `scaleX(${p})`,
                  }}
                />
              );
            })}
            {KEYS.map((k, i) => {
              const pop = interpolate(pr, [k.x, k.x + 0.05, k.x + 0.1], [1, 1.6, 1], clamp);
              const passed = interpolate(pr, [k.x - 0.01, k.x + 0.01], [0.55, 1], clamp);
              return (
                <div
                  key={i}
                  style={{
                    position: "absolute",
                    top: k.track * 50 + 9,
                    left: k.x * INNER - 10,
                    width: 20,
                    height: 20,
                    background: theme.colors.text,
                    opacity: head * passed,
                    transform: `rotate(45deg) scale(${pop})`,
                    borderRadius: 3,
                  }}
                />
              );
            })}
            {/* playhead */}
            <div
              style={{
                position: "absolute",
                top: -10,
                left: pr * INNER - 2,
                width: 4,
                height: 160,
                borderRadius: 2,
                background: theme.colors.text,
                opacity: head,
              }}
            />
          </div>
        </div>
      </Entrance>
    </div>
  );
};

const LineDim: React.FC<{next: number; children: React.ReactNode}> = ({next, children}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [next, next + 10], [1, 0.62], clamp);
  return <div style={{opacity: o}}>{children}</div>;
};

// Cue 3 — "AI দিয়ে মোশন গ্রাফিক্স ভিডিও বানানো যায়।": a video gets built, then renders.
export const SceneC: React.FC = () => {
  const frame = useCurrentFrame();
  const t = {
    ai: local(SCENES.c, WORDS.c.ai),
    motion: local(SCENES.c, WORDS.c.motion),
    video: local(SCENES.c, WORDS.c.video),
    banano: local(SCENES.c, WORDS.c.banano),
  };
  const sceneLen = TOTAL - SCENES.c.from;
  const renderStart = t.banano;
  const renderEnd = Math.min(t.banano + fr(1300), sceneLen - 16);

  const fill = interpolate(frame, [renderStart, renderEnd], [0, 1], {
    easing: theme.ease.inOut,
    ...clamp,
  });
  const doneP = useEnter(renderEnd, theme.spring.bouncy);
  const checkDraw = interpolate(frame, [renderEnd + 2, renderEnd + 14], [0, 1], {
    easing: theme.ease.out,
    ...clamp,
  });

  return (
    <SceneShell exit={false}>
      <AbsoluteFill
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: 40,
          padding: "0 120px",
        }}
      >
        {/* left: words land one by one */}
        <div style={{width: 820, letterSpacing: 0, whiteSpace: "nowrap"}}>
          <LineDim next={t.motion}>
            <div style={{display: "flex", alignItems: "baseline", gap: 28, lineHeight: 1.4}}>
              <span style={{fontSize: 230, fontWeight: theme.weights.bold}}>
                <MaskText delay={t.ai} config={theme.spring.bouncy}>
                  <GradientText sweepFrom={t.ai}>AI</GradientText>
                </MaskText>
              </span>
              <span style={{fontSize: 110, fontWeight: theme.weights.bold}}>
                <MaskText delay={t.ai + 4}>দিয়ে</MaskText>
              </span>
            </div>
          </LineDim>
          <LineDim next={t.video}>
            <div style={{fontSize: 104, fontWeight: theme.weights.bold, lineHeight: 1.4}}>
              <MaskText delay={t.motion}>মোশন গ্রাফিক্স</MaskText>
            </div>
          </LineDim>
          <LineDim next={t.banano}>
            <div style={{fontSize: 104, fontWeight: theme.weights.bold, lineHeight: 1.4}}>
              <MaskText delay={t.video}>ভিডিও</MaskText>
            </div>
          </LineDim>
          <div style={{fontSize: 104, fontWeight: theme.weights.bold, lineHeight: 1.4}}>
            <MaskText delay={t.banano} config={theme.spring.bouncy}>
              <GradientText sweepFrom={t.banano}>বানানো যায়।</GradientText>
            </MaskText>
          </div>
        </div>

        {/* right: editor + render bar */}
        <div style={{width: CARD_W, display: "flex", flexDirection: "column", gap: 34}}>
          <Editor
            enter={t.ai + 5}
            clipsAt={t.motion}
            playStart={t.video}
            playEnd={t.video + fr(2300)}
          />
          <Entrance delay={t.video} y={30}>
            <div style={{display: "flex", alignItems: "center", gap: 24}}>
              <div
                style={{
                  flex: 1,
                  height: 20,
                  borderRadius: 10,
                  background: theme.colors.glass,
                  border: `1.5px solid ${theme.colors.stroke}`,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    width: `${fill * 100}%`,
                    height: "100%",
                    borderRadius: 10,
                    background: `linear-gradient(90deg, ${theme.colors.primary}, ${theme.colors.accent})`,
                  }}
                />
              </div>
              <svg width={64} height={64} viewBox="0 0 84 84">
                <circle cx={42} cy={42} r={36} fill="none" stroke={theme.colors.stroke} strokeWidth={4} />
                <g
                  style={{
                    transformOrigin: "42px 42px",
                    transform: `scale(${interpolate(doneP, [0, 1], [0.6, 1])})`,
                    opacity: doneP,
                  }}
                >
                  <circle cx={42} cy={42} r={36} fill={theme.colors.accent} />
                  <path
                    d="M25 43 L37 55 L60 30"
                    fill="none"
                    stroke={theme.colors.text}
                    strokeWidth={7}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    pathLength={1}
                    strokeDasharray={1}
                    strokeDashoffset={1 - checkDraw}
                  />
                </g>
              </svg>
            </div>
          </Entrance>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
