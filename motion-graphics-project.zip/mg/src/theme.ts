// Single source of truth. No inline colors / easings / springs in components.
import {Easing} from "remotion";
import {fontFamily} from "./fonts";

export const theme = {
  colors: {
    bg: "#0E0A1F",
    bgAlt: "#17102E",
    primary: "#8B5CF6", // hero
    accent: "#FF4FD8",
    text: "#F5F0FF",
    textDim: "#B9AEDB",
    glass: "rgba(245,240,255,0.06)",
    stroke: "rgba(245,240,255,0.14)",
    glow: "rgba(139,92,246,0.45)",
  },
  fonts: {
    main: `${fontFamily}, "Noto Sans Bengali", sans-serif`,
  },
  weights: {regular: 500, bold: 700},
  radius: {sm: 16, md: 28, lg: 40},
  shadow: {
    card: "0 40px 80px -20px rgba(0,0,0,0.6)",
    heroGlow: "0 0 60px rgba(139,92,246,0.4), 0 0 120px rgba(139,92,246,0.2)",
  },
  space: {sm: 16, md: 32, lg: 64, xl: 120},
  dur: {enter: 20, exit: 12},
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;
